DROP TABLE IF EXISTS `#__cs_filebank_files`;
