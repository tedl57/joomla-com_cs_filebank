CREATE TABLE IF NOT EXISTS `#__cs_filebank_files` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`by_username` VARCHAR(32)  NOT NULL ,
`date_added` DATETIME NOT NULL ,
`idate` DATETIME NOT NULL ,
`last_updated` DATETIME NOT NULL ,
`icategory` VARCHAR(255)  NOT NULL ,
`iname` VARCHAR(255)  NOT NULL ,
`isize` INT NOT NULL ,
`itype` VARCHAR(32)  NOT NULL ,
`ictype` VARCHAR(32)  NOT NULL ,
`iaccess` INT NOT NULL ,
`archived` INT NOT NULL ,
`email_notified` VARCHAR(255)  NOT NULL ,
`idescription` LONGTEXT NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

